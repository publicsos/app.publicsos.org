<div class="nav-item dropdown me-2">
    <a class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown" href="#" aria-label="Open user menu">
        <svg
            class="icon icon-tabler icons-tabler-outline icon-tabler-language"
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
        >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M4 5h7" />
            <path d="M9 3v2c0 4.418 -2.239 8 -5 8" />
            <path d="M5 9c0 2.144 2.952 3.908 6.7 4" />
            <path d="M12 20l4 -9l4 9" />
            <path d="M19.1 18h-6.2" />
        </svg>
        &nbsp;{{ strtoupper(App::getLocale()) }}
    </a>
    <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
        @foreach (config("app.available_locales") as $locale_code => $locale_name)
            <a class="dropdown-item" href="{{ route("language.switch", $locale_code) }}">{{ $locale_name }}</a>
        @endforeach
    </div>
</div>
